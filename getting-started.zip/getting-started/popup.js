document.addEventListener("DOMContentLoaded", function () {
	var List = [];
	var updateTime = "";
	var status = "";
	var timer;
	var lastPrice = 0;
	var priceChangePercent = 0;
	var HTML = `<div class="row border-bottom py-2">
        <div class="col-4">{{symbol}}</div>
        <div class="col-4">\${{lastPrice}}</div>
        <div class="col-4"><span class="badge {{status}}">{{priceChangePercent}}%</span></div>
    </div>`;

	function InitData() {
		fetch("https://api1.binance.com/api/v3/ticker/24hr")
			.then((res) => res.json())
			.then((data) => {
				var HTML_GROUP = "";
				List = [];
				$("#app").html("");
				data.forEach((v, i) => {
					if (v.symbol == "BTCUSDT") {
						List.push(v);
					}
					if (v.symbol == "DOGEBTC") {
						List.push(v);
					}
					if (v.symbol == "DOGEUSDT") {
						List.push(v);
					}
				});
				List.forEach((v, i) => {
					status = "";
					lastPrice = +v.lastPrice;
					if (parseInt(v.priceChangePercent) > 0) {
						status = "bg-danger";
						priceChangePercent = "+" + v.priceChangePercent;
					} else {
						status = "bg-success";
						priceChangePercent = v.priceChangePercent;
					}
					switch (v.symbol) {
						case "BTCUSDT":
							lastPrice = lastPrice.toFixed(2);
							break;
						case "DOGEUSDT":
							lastPrice = lastPrice.toFixed(4);
							break;
						default:
							lastPrice = lastPrice;
							break;
					}
					HTML_GROUP += HTML.replace("{{symbol}}", v.symbol).replace("{{lastPrice}}", lastPrice).replace("{{priceChangePercent}}", priceChangePercent).replace("{{status}}", status);
				});
				updateTime = new Date(List[0].closeTime);
				$("#app").append(HTML_GROUP);
				$(".updateTime").html(`${updateTime.getHours()}:${updateTime.getMinutes()}:${updateTime.getSeconds()}`);
			});
	}
	function RunData() {
		StopData();
		timer = setInterval(() => {
			InitData();
		}, 1000 * 15);
	}
	function StopData() {
		clearInterval(timer);
	}
	InitData();
	document.getElementById("reload").addEventListener("click", function () {
		InitData();
		StopData();
		RunData();
	});
});
