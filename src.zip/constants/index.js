export const SET_GAMES="SET_GAMES";
export const ADD_GAME="ADD_GAME"
export const GAME_FETCHED="GAME_FETCHED"
export const GAME_UPDATED="GAME_UPDATED"
export const GAME_DELETE="GAME_DELETE"