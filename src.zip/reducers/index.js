import {combineReducers} from 'redux'
import games from './games'

export default combineReducers({
    games
})