import React from 'react'
import {connect} from 'react-redux'
import GamesList from './GamesList'
import {fetchGames,deleteGame} from '../actions'

class GamesPage extends React.Component{
    componentDidMount(){
        this.props.fetchGames();
    }
    render(){
        return (
            <div>
                <GamesList games={this.props.games} deleteGame={this.props.deleteGame} />
            </div>
        )
    }
}

const mapState=(state)=>{
    return {
        games:state.games
    }
}

export default connect(mapState,{fetchGames,deleteGame})(GamesPage)