import React from 'react'
import {connect} from  'react-redux'
import {saveGames,fetchGame,updateGames} from '../actions'
import {Redirect} from 'react-router-dom'
import GameForm from './GameForm'

class GameFormPage extends React.Component{
    state={
        redirect:false
    }
    componentDidMount(){
        const {match}=this.props;
        if(match.params._id){
            this.props.fetchGame(match.params._id)
        }
    }
    saveGame=({_id,title,cover})=>{
        if(_id){
            return this.props.updateGames({_id,title,cover}).then(()=>{
                return this.setState({redirect:true})
            })
        }else{
            return this.props.saveGames({title,cover}).then(()=>{
                return this.setState({redirect:true})
            })
        }
    }

    render(){
        return (
            <div>
                {
                    this.state.redirect?
                    <Redirect to="/games" />:
                    <GameForm 
                        saveGame={this.saveGame}
                        game={this.props.game}
                    />
                }
            </div>
        )
    }
}

const mapState=(state,props)=>{
    const {match}=props;
    if(match.params._id){
        return {
            game:state.games.find(item=>item._id === match.params._id)
        }
    }
    return {
        game:null
    }
}

export default connect(mapState,{saveGames,fetchGame,updateGames})(GameFormPage)