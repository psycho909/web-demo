import React,{Component} from 'react';

let name="Chen";

export default class Hello extends Component{
    render(){
        return (
            <div>{name} Hello pasasddage 1</div>
        )
    }
}