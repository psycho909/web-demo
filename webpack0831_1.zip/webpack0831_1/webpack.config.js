const path = require('path')
const autoprefixer = require('autoprefixer')
const HtmlWebpackPlugin = require('html-webpack-plugin')
const {CleanWebpackPlugin} = require('clean-webpack-plugin')
const webpack = require('webpack')
const ImageminPlugin = require('imagemin-webpack')
const MiniCssExtractPlugin = require('mini-css-extract-plugin');

module.exports = {
    entry: {
        "page1":"./src/page1/js/index.js",
        "page2":"./src/page2/js/index.js",
    },
    output: {
        path: path.resolve(__dirname, 'dist'),
        filename: 'bundle.js',
        publicPath:"./", // 资源路径前缀，一般会使用CDN地址，这样图片和CSS就会使用CDN的绝对URL
    },
    devServer: {
        contentBase: '/dist/',
        port: 9000,
        inline: true,
        historyApiFallback: true,
        hot: true,
    },
    devtool: 'source-map',
    module: {
        rules: [
            {
                test: /\.scss$/,
                use:[
                    {
                        loader:MiniCssExtractPlugin.loader,
                        options:{
                            reloadAll: true,
                            publicPath:"../"
                        }
                    },{
                        loader:"css-loader"
                    },{
                        loader:"postcss-loader",
                        options:{
                            plugins:[require("autoprefixer")]
                        }
                    },{
                        loader:"sass-loader",
                        options:{
                            sassOptions:{
                                outputStyle: 'nested'
                            }
                        }
                    }
                ]
            },
            {
                test: /(\.jsx|\.js)$/,
                use: {
                    loader: 'babel-loader',
                },
                exclude: /node_modules/,
            },
            {
                test:/\.html$/,
                use:[
                    {
                        loader:"html-loader",
                        options:{
                            minimize:true
                        }
                    }
                ]
            },
            {
                test: /\.(png|jpg|gif|jpe?g|svg)$/,
                use: [
                    {
                        loader: 'file-loader',
                        options: {
                            context: path.resolve(__dirname, "src/"),
                            name: '[name].[ext]',
                            outputPath: 'images',
                            useRelativePaths:true
                        },
                    },
                    {
                        loader:ImageminPlugin.loader,
                        options:{
                            bail:false,
                            cache:false,
                            imageminOptions:{
                                plugins:[
                                    ["pngquant",{
                                        quality:[0.3,0.5],
                                        speed:1
                                    }],
                                    ["mozjpeg",{
                                        quality:50,
                                        progressive:true
                                    }],
                                ]
                            }
                        }
                    }
                ],
            },
        ],
    },
    plugins: [
        new HtmlWebpackPlugin({
            template:"./src/page1/index.html",
            filename:"page1.html",
            chunks:["page1"]
        }),
        new HtmlWebpackPlugin({
            template:"./src/page2/index.html",
            filename:"page2.html",
            chunks:["page2"]
        }),
        // new CleanWebpackPlugin(["dist"]),
        new webpack.HotModuleReplacementPlugin(),
        new MiniCssExtractPlugin({
            filename:"css/[name].css",
            chunkFilename:"css/[id].css",
        }),
    ],
}
